#!/usr/bin/env python3
import os
import psycopg2
from neo4j import GraphDatabase

# ========== 1. Настройки ==========
PG_HOST     = os.getenv("PG_HOST",     "localhost")
PG_PORT     = int(os.getenv("PG_PORT", 5433))
PG_DBNAME   = os.getenv("PG_DBNAME",   "amina")
PG_USER     = os.getenv("PG_USER",     "amina")
PG_PASSWORD = os.getenv("PG_PASSWORD", "12345")

NEO_URI      = os.getenv("NEO_URI",      "bolt://localhost:7687")
NEO_USER     = os.getenv("NEO_USER",     "neo4j")
NEO_PASSWORD = os.getenv("NEO_PASSWORD", "amina_malina")

BATCH_SIZE = 500

# ========== 2. Подключения ==========
pg_conn     = psycopg2.connect(
    host=PG_HOST, port=PG_PORT,
    dbname=PG_DBNAME, user=PG_USER, password=PG_PASSWORD
)
neo_driver  = GraphDatabase.driver(NEO_URI, auth=(NEO_USER, NEO_PASSWORD))

# ========== 3. Создание ограничений (один раз) ==========
def create_constraints():
    with neo_driver.session() as sess:
        sess.execute_write(lambda tx: tx.run(
            "CREATE CONSTRAINT IF NOT EXISTS "
            "FOR (n:NewsResultCatboost) REQUIRE n.id IS UNIQUE"
        ))
        sess.execute_write(lambda tx: tx.run(
            "CREATE CONSTRAINT IF NOT EXISTS "
            "FOR (n:NewsResultBert) REQUIRE n.id IS UNIQUE"
        ))

# ========== 4. Функция импорта таблицы ==========
def import_table(table_name, label, columns):
    pg_cursor = pg_conn.cursor()
    pg_cursor.execute(f"SELECT {', '.join(c for c,_ in columns)} FROM {table_name}")

    def batch_writer(tx, batch):
        # Генерируем список SET выражений вида "n.col = row.col" или с приведением
        sets = []
        for col, fn in columns:
            if col == "id":
                continue
            expr = f"row.{col}"
            if fn == "toInteger":
                expr = f"toInteger({expr})"
            elif fn == "datetime":
                expr = f"datetime({expr})"
            sets.append(f"n.{col} = {expr}")
        sets_cypher = ",\n    ".join(sets)

        cypher = f"""
        UNWIND $rows AS row
        MERGE (n:{label} {{id: row.id}})
        SET
            {sets_cypher}
        """
        tx.run(cypher, rows=batch)

    batch = []
    count = 0
    for rec in pg_cursor:
        row = {}
        for (col, fn), val in zip(columns, rec):
            # Подготовка параметров в Python-слое
            if fn == "toInteger":
                row[col] = int(val) if val is not None else None
            elif fn == "datetime":
                row[col] = val.isoformat() if val is not None else None
            else:
                row[col] = val
        batch.append(row)

        if len(batch) >= BATCH_SIZE:
            with neo_driver.session() as sess:
                sess.execute_write(batch_writer, batch)
            count += len(batch)
            print(f"  imported {count} rows into :{label}")
            batch.clear()

    # Остаток
    if batch:
        with neo_driver.session() as sess:
            sess.execute_write(batch_writer, batch)
        count += len(batch)
        print(f"  imported {count} rows into :{label}")

    pg_cursor.close()

# ========== 5. Основной блок ==========
if __name__ == "__main__":
    # Создаём ограничения
    create_constraints()

    tables = [
        (
            "news_result_catboost",
            "NewsResultCatboost",
            [
                ("id",         None),
                ("public_date","datetime"),
                ("txt",        None),
                ("link",       None),
                ("picture",    None),
                ("video",      None),
                ("word_count", "toInteger"),
                ("category",   None),
            ]
        ),
        (
            "news_result_bert",
            "NewsResultBert",
            [
                ("id",         None),
                ("public_date","datetime"),
                ("txt",        None),
                ("link",       None),
                ("picture",    None),
                ("video",      None),
                ("word_count", "toInteger"),
                ("category",   None),
            ]
        ),
    ]

    print("Starting import…")
    for table_name, label, cols in tables:
        print(f">>> Importing {table_name} → :{label}")
        import_table(table_name, label, cols)
    print("Done.")

    neo_driver.close()
    pg_conn.close()
